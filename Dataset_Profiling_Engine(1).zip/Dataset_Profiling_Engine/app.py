
import os
import tkinter as tk
from tkinter import ttk, filedialog, messagebox
from matplotlib.figure import Figure
from matplotlib.backends.backend_tkagg import FigureCanvasTkAgg

from dataset_profiler import DatasetProfiler


class DatasetProfilingApp:
    def __init__(self, root):
        self.root = root
        self.root.title("Dataset Profiling Engine")
        self.root.geometry("1250x760")
        self.root.minsize(1000, 650)

        self.profiler = None
        self.current_file = None
        self.chart_canvas = None

        self.create_interface()

    def create_interface(self):
        title = ttk.Label(
            self.root,
            text="DATASET PROFILING ENGINE",
            font=("Arial", 20, "bold")
        )
        title.pack(pady=(15, 5))

        subtitle = ttk.Label(
            self.root,
            text="Profile schema, data types, missing values, duplicates, unique values and distributions",
            font=("Arial", 10)
        )
        subtitle.pack(pady=(0, 12))

        file_frame = ttk.Frame(self.root, padding=10)
        file_frame.pack(fill="x", padx=20)

        ttk.Label(file_frame, text="Dataset File:", font=("Arial", 10, "bold")).pack(side="left")

        self.file_label = ttk.Label(file_frame, text="No file selected", width=70)
        self.file_label.pack(side="left", padx=10)

        ttk.Button(
            file_frame,
            text="Browse Dataset",
            command=self.browse_file
        ).pack(side="left")

        ttk.Button(
            file_frame,
            text="Export JSON Report",
            command=self.export_report
        ).pack(side="right")

        self.notebook = ttk.Notebook(self.root)
        self.notebook.pack(fill="both", expand=True, padx=20, pady=10)

        self.overview_tab = ttk.Frame(self.notebook)
        self.preview_tab = ttk.Frame(self.notebook)
        self.schema_tab = ttk.Frame(self.notebook)
        self.missing_tab = ttk.Frame(self.notebook)
        self.duplicates_tab = ttk.Frame(self.notebook)
        self.unique_tab = ttk.Frame(self.notebook)
        self.statistics_tab = ttk.Frame(self.notebook)
        self.distribution_tab = ttk.Frame(self.notebook)

        self.notebook.add(self.overview_tab, text="Overview")
        self.notebook.add(self.preview_tab, text="Dataset Preview")
        self.notebook.add(self.schema_tab, text="Schema")
        self.notebook.add(self.missing_tab, text="Missing Values")
        self.notebook.add(self.duplicates_tab, text="Duplicates")
        self.notebook.add(self.unique_tab, text="Unique Values")
        self.notebook.add(self.statistics_tab, text="Statistics")
        self.notebook.add(self.distribution_tab, text="Distributions")

        self.status = ttk.Label(
            self.root,
            text="Select a CSV, Excel, or JSON dataset to begin.",
            relief="sunken",
            anchor="w",
            padding=5
        )
        self.status.pack(fill="x", side="bottom")

    def browse_file(self):
        file_path = filedialog.askopenfilename(
            title="Select Dataset",
            filetypes=[
                ("Supported Files", "*.csv *.xlsx *.xls *.json"),
                ("CSV Files", "*.csv"),
                ("Excel Files", "*.xlsx *.xls"),
                ("JSON Files", "*.json")
            ]
        )

        if not file_path:
            return

        try:
            self.current_file = file_path
            self.profiler = DatasetProfiler(file_path)
            self.profiler.load_dataset()
            self.profiler.generate_profile()

            self.file_label.config(text=os.path.basename(file_path))
            self.populate_all_tabs()
            self.status.config(text=f"Dataset loaded successfully: {file_path}")

            messagebox.showinfo(
                "Success",
                "Dataset loaded and profiled successfully."
            )

        except Exception as error:
            messagebox.showerror("Error", str(error))
            self.status.config(text="Failed to load dataset.")

    def clear_tab(self, tab):
        for widget in tab.winfo_children():
            widget.destroy()

    def create_treeview(self, parent, dataframe):
        container = ttk.Frame(parent)
        container.pack(fill="both", expand=True, padx=10, pady=10)

        if dataframe is None or dataframe.empty:
            ttk.Label(
                container,
                text="No data available for this section."
            ).pack(pady=30)
            return

        columns = list(dataframe.columns)

        tree = ttk.Treeview(
            container,
            columns=columns,
            show="headings"
        )

        vertical = ttk.Scrollbar(container, orient="vertical", command=tree.yview)
        horizontal = ttk.Scrollbar(container, orient="horizontal", command=tree.xview)

        tree.configure(
            yscrollcommand=vertical.set,
            xscrollcommand=horizontal.set
        )

        for column in columns:
            tree.heading(column, text=str(column))
            tree.column(column, width=150, anchor="center")

        for _, row in dataframe.iterrows():
            values = []
            for value in row.tolist():
                if value is None:
                    values.append("")
                else:
                    values.append(str(value))
            tree.insert("", "end", values=values)

        tree.grid(row=0, column=0, sticky="nsew")
        vertical.grid(row=0, column=1, sticky="ns")
        horizontal.grid(row=1, column=0, sticky="ew")

        container.rowconfigure(0, weight=1)
        container.columnconfigure(0, weight=1)

    def populate_all_tabs(self):
        df = self.profiler.df

        self.show_overview()
        self.show_preview(df)
        self.show_table_tab(self.schema_tab, self.profiler.schema())
        self.show_table_tab(self.missing_tab, self.profiler.missing_values())
        self.show_duplicates()
        self.show_table_tab(self.unique_tab, self.profiler.unique_values())
        self.show_table_tab(self.statistics_tab, self.profiler.numeric_statistics())
        self.show_distribution()

    def show_overview(self):
        self.clear_tab(self.overview_tab)

        info = self.profiler.basic_information()
        duplicate_info = self.profiler.duplicate_information()
        total_missing = int(self.profiler.df.isna().sum().sum())

        content = ttk.Frame(self.overview_tab, padding=30)
        content.pack(fill="both", expand=True)

        cards = [
            ("Rows", info["Rows"]),
            ("Columns", info["Columns"]),
            ("Missing Values", total_missing),
            ("Duplicate Rows", duplicate_info["Duplicate Rows"])
        ]

        for index, (label, value) in enumerate(cards):
            card = ttk.LabelFrame(content, text=label, padding=20)
            card.grid(row=0, column=index, padx=10, pady=20, sticky="nsew")

            ttk.Label(
                card,
                text=str(value),
                font=("Arial", 24, "bold")
            ).pack(padx=30, pady=20)

            content.columnconfigure(index, weight=1)

        details = ttk.LabelFrame(content, text="Dataset Information", padding=15)
        details.grid(row=1, column=0, columnspan=4, sticky="ew", padx=10, pady=10)

        ttk.Label(
            details,
            text=f"Columns: {info['Column Names']}",
            wraplength=1000,
            justify="left"
        ).pack(anchor="w", pady=5)

        ttk.Label(
            details,
            text=f"File: {self.current_file}",
            wraplength=1000,
            justify="left"
        ).pack(anchor="w", pady=5)

    def show_preview(self, dataframe):
        self.clear_tab(self.preview_tab)
        self.create_treeview(self.preview_tab, dataframe.head(100))

    def show_table_tab(self, tab, dataframe):
        self.clear_tab(tab)
        self.create_treeview(tab, dataframe)

    def show_duplicates(self):
        self.clear_tab(self.duplicates_tab)

        info = self.profiler.duplicate_information()
        frame = ttk.Frame(self.duplicates_tab, padding=30)
        frame.pack(fill="both", expand=True)

        for key, value in info.items():
            row = ttk.Frame(frame)
            row.pack(fill="x", pady=10)

            ttk.Label(
                row,
                text=f"{key}:",
                font=("Arial", 13, "bold"),
                width=25
            ).pack(side="left")

            ttk.Label(
                row,
                text=str(value),
                font=("Arial", 13)
            ).pack(side="left")

    def show_distribution(self):
        self.clear_tab(self.distribution_tab)

        numeric_columns = self.profiler.df.select_dtypes(include="number").columns.tolist()

        if not numeric_columns:
            ttk.Label(
                self.distribution_tab,
                text="No numeric columns available for distribution analysis."
            ).pack(pady=40)
            return

        top_frame = ttk.Frame(self.distribution_tab, padding=10)
        top_frame.pack(fill="x")

        ttk.Label(top_frame, text="Select Numeric Column:").pack(side="left")

        selected_column = tk.StringVar(value=numeric_columns[0])

        combo = ttk.Combobox(
            top_frame,
            textvariable=selected_column,
            values=numeric_columns,
            state="readonly",
            width=30
        )
        combo.pack(side="left", padx=10)

        chart_frame = ttk.Frame(self.distribution_tab)
        chart_frame.pack(fill="both", expand=True)

        def draw_chart(*args):
            for widget in chart_frame.winfo_children():
                widget.destroy()

            column = selected_column.get()
            data = self.profiler.df[column].dropna()

            figure = Figure(figsize=(8, 5), dpi=100)
            axis = figure.add_subplot(111)

            axis.hist(data, bins=20, edgecolor="black")
            axis.set_title(f"Distribution of {column}")
            axis.set_xlabel(column)
            axis.set_ylabel("Frequency")

            canvas = FigureCanvasTkAgg(figure, master=chart_frame)
            canvas.draw()
            canvas.get_tk_widget().pack(fill="both", expand=True)

        combo.bind("<<ComboboxSelected>>", draw_chart)
        draw_chart()

    def export_report(self):
        if not self.profiler:
            messagebox.showwarning(
                "No Dataset",
                "Please load a dataset before exporting a report."
            )
            return

        output_path = filedialog.asksaveasfilename(
            title="Save Profiling Report",
            defaultextension=".json",
            initialfile="dataset_profile_report.json",
            filetypes=[("JSON Files", "*.json")]
        )

        if not output_path:
            return

        try:
            self.profiler.save_report(output_path)
            self.status.config(text=f"Report exported successfully: {output_path}")

            messagebox.showinfo(
                "Export Successful",
                f"Profiling report saved successfully.\n\n{output_path}"
            )

        except Exception as error:
            messagebox.showerror("Export Error", str(error))


if __name__ == "__main__":
    root = tk.Tk()
    app = DatasetProfilingApp(root)
    root.mainloop()
