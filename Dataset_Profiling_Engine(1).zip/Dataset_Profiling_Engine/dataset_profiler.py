
import os
import json
import pandas as pd
import numpy as np


class DatasetProfiler:
    """Reusable engine for profiling CSV, Excel and JSON datasets."""

    def __init__(self, file_path):
        self.file_path = file_path
        self.df = None
        self.profile = {}

    def load_dataset(self):
        extension = os.path.splitext(self.file_path)[1].lower()

        if extension == ".csv":
            self.df = pd.read_csv(self.file_path)
        elif extension in [".xlsx", ".xls"]:
            self.df = pd.read_excel(self.file_path)
        elif extension == ".json":
            self.df = pd.read_json(self.file_path)
        else:
            raise ValueError("Unsupported format. Please select CSV, Excel, or JSON.")

        if self.df.empty:
            raise ValueError("The selected dataset is empty.")

        return self.df

    def basic_information(self):
        return {
            "Rows": int(self.df.shape[0]),
            "Columns": int(self.df.shape[1]),
            "Column Names": ", ".join(map(str, self.df.columns))
        }

    def schema(self):
        return pd.DataFrame({
            "Column": self.df.columns,
            "Data Type": [str(dtype) for dtype in self.df.dtypes],
            "Non-Null Count": [int(self.df[col].notna().sum()) for col in self.df.columns]
        })

    def missing_values(self):
        result = pd.DataFrame({
            "Column": self.df.columns,
            "Missing Values": self.df.isna().sum().values,
            "Missing Percentage": (
                self.df.isna().sum().values / len(self.df) * 100
            ).round(2)
        })
        return result

    def duplicate_information(self):
        duplicate_rows = int(self.df.duplicated().sum())
        return {
            "Total Rows": int(len(self.df)),
            "Duplicate Rows": duplicate_rows,
            "Unique Rows": int(len(self.df) - duplicate_rows)
        }

    def unique_values(self):
        return pd.DataFrame({
            "Column": self.df.columns,
            "Unique Values": [int(self.df[col].nunique(dropna=True)) for col in self.df.columns]
        })

    def numeric_statistics(self):
        numeric_df = self.df.select_dtypes(include=[np.number])

        if numeric_df.empty:
            return pd.DataFrame()

        stats = numeric_df.describe().T.reset_index()
        stats.rename(columns={"index": "Column"}, inplace=True)
        return stats.round(3)

    def categorical_summary(self):
        categorical_cols = self.df.select_dtypes(include=["object", "category", "bool"]).columns
        rows = []

        for col in categorical_cols:
            counts = self.df[col].value_counts(dropna=True)
            most_frequent = counts.index[0] if not counts.empty else "N/A"
            frequency = int(counts.iloc[0]) if not counts.empty else 0

            rows.append({
                "Column": col,
                "Unique Values": int(self.df[col].nunique(dropna=True)),
                "Most Frequent": str(most_frequent),
                "Frequency": frequency
            })

        return pd.DataFrame(rows)

    def generate_profile(self):
        self.profile = {
            "basic_information": self.basic_information(),
            "duplicate_information": self.duplicate_information(),
            "schema": self.schema().to_dict(orient="records"),
            "missing_values": self.missing_values().to_dict(orient="records"),
            "unique_values": self.unique_values().to_dict(orient="records"),
            "numeric_statistics": self.numeric_statistics().replace(
                {np.nan: None}
            ).to_dict(orient="records"),
            "categorical_summary": self.categorical_summary().to_dict(orient="records")
        }
        return self.profile

    def save_report(self, output_path):
        if not self.profile:
            self.generate_profile()

        folder = os.path.dirname(output_path)
        if folder:
            os.makedirs(folder, exist_ok=True)

        with open(output_path, "w", encoding="utf-8") as file:
            json.dump(self.profile, file, indent=4, default=str)

        return output_path
