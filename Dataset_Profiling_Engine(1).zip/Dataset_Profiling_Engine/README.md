# Dataset Profiling Engine

## Overview
A desktop GUI application for profiling datasets using Python.

## Features
- Browse button for dataset selection
- Supports CSV, Excel and JSON files
- Dataset preview
- Schema and data type analysis
- Missing value analysis
- Duplicate row detection
- Unique value analysis
- Numeric statistical summary
- Data distribution charts
- JSON report export

## Technologies
- Python
- Tkinter
- Pandas
- NumPy
- Matplotlib

## Installation
Open Command Prompt inside this project folder and run:

pip install -r requirements.txt

## Run the Application

python app.py

Then click **Browse Dataset** and select your CSV, Excel or JSON file.

## Project Structure

Dataset_Profiling_Engine/
├── app.py
├── dataset_profiler.py
├── requirements.txt
├── README.md
├── data/
└── reports/
